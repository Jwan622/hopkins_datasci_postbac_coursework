public class Dealer extends Player {
    public static final int minimumStop = 17;
}
